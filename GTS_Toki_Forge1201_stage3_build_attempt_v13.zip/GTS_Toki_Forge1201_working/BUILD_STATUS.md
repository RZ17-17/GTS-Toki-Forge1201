# GTS Toki & More GTS — Forge 1.20.1 port

## Build target
- Minecraft: 1.20.1
- Forge: 47.2.20
- Java toolchain: 17
- GeckoLib: 4.4.9 for Forge 1.20.1

## Build command
Run from this directory in an environment with internet access and Java 17 installed:

```bash
gradle build
```

The resulting mod JAR should be in `build/libs/` after a successful build.

## Latest build attempt (2026-10-17)
- Gradle 8.5 archive supplied by the user was integrity-checked and extracted successfully.
- Gradle 8.5 launches correctly on the available OpenJDK 21 runtime.
- First build attempt stopped while resolving `org.gradle.toolchains.foojay-resolver-convention:0.8.0`.
- A diagnostic retry with that optional settings plugin temporarily removed proceeded further, then stopped resolving `net.minecraftforge.gradle` version `[6.0,6.2)`.
- Direct DNS resolution for `plugins.gradle.org` fails in this execution environment (`curl: (6) Could not resolve host: plugins.gradle.org`). This is an environment/dependency-fetch blocker, not evidence that Java source compilation passed or failed.
- The original `settings.gradle` was restored after the diagnostic retry.

## Current verification status
- Project source and assets are included in this archive.
- JSON resources were previously validated syntactically; current source count is 288 Java files and 95 files under `src/main/resources`.
- No successful Gradle compilation has occurred. No playable JAR has been generated, and no in-game launch test has been performed. Do not treat this source archive as a tested playable JAR.

## Dependency note
The separate minimal `build.gradle` uploaded during Stage 2 omits GeckoLib, which the ported source uses. This project keeps the fuller build configuration so GeckoLib can be resolved during the real build.
